﻿CREATE TABLE [dbo].[LogInUsers] (
    [CustID]      INT          IDENTITY (100, 1) NOT NULL,
    [CustName]    VARCHAR (20) NOT NULL,
    [Passwd]      VARCHAR (20) NOT NULL,
    [ConfmPasswd] VARCHAR (20) NOT NULL,
    PRIMARY KEY CLUSTERED ([CustID] ASC)
);

