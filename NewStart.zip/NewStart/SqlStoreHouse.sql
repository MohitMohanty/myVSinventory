create database StoreHouse;
use StoreHouse;
'create table LogInUsers (CustID int PRIMARY KEY IDENTITY (100,1), CustName varchar(20),Passwd varchar(20));'

insert into LogInUsers values('MohitMohanty','Mohit@123');
insert into LogInUsers values('Laxma34','Laxma@123');
insert into LogInUsers values('Harikrishnan','Hari@123');
insert into LogInUsers values('ChetanK','Chetan@123');

Create table Products(PID int primary key identity (1,1),PName varchar(20) unique not null,PAmt int not null);

select * from LogInUsers;
delete LogInUsers where CustID = 107;

select CustID from LogInUsers where CustName = 'laxma';