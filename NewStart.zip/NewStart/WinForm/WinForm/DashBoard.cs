﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
  
    public partial class DashBoard : Form
    {
        string Geth;
        public DashBoard(string Name)
        {
            InitializeComponent();
            Geth = Name;
        }

        
        private void DashBoard_Load(object sender, EventArgs e)
        {

            LogIn lg = new LogIn();
            lblshow.Text += Geth + " Hello to your interface";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
            
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn lg = new LogIn();
            lg.Show();
        }

        private void BtnUpdateData(object sender, LinkLabelLinkClickedEventArgs e)
        {
            UpdateUserPass ups = new UpdateUserPass();
            ups.Show();   
        }
      

        private void BtnAdditem(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AddProducts ap = new AddProducts();
            ap.Show();
            

        }
        SqlConnection scon = null;
        private void btnshowItem_Click(object sender, EventArgs e)
        {
            scon = new SqlConnection("Data Source=MOHIT-PC;Initial Catalog=StoreHouse;Integrated Security=True");

            scon.Open();
            SqlCommand scmd = new SqlCommand("Select PName,PAmt from Products", scon);

            SqlDataReader sdr = scmd.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(sdr);
            
            showDashProducts.DataSource =dt;
            
        }
    }
}
