﻿namespace WinForm
{
    partial class UpdateUserPass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpdteSubmit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUserChng = new System.Windows.Forms.TextBox();
            this.txtPassChng = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnUpdteSubmit
            // 
            this.btnUpdteSubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnUpdteSubmit.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdteSubmit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdteSubmit.Location = new System.Drawing.Point(405, 251);
            this.btnUpdteSubmit.Name = "btnUpdteSubmit";
            this.btnUpdteSubmit.Size = new System.Drawing.Size(109, 47);
            this.btnUpdteSubmit.TabIndex = 0;
            this.btnUpdteSubmit.Text = "Submit";
            this.btnUpdteSubmit.UseVisualStyleBackColor = false;
            this.btnUpdteSubmit.Click += new System.EventHandler(this.btnUpdteSubmit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(68, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(281, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter User Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(68, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(391, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "Enter the New Password :";
            // 
            // txtUserChng
            // 
            this.txtUserChng.Font = new System.Drawing.Font("Lucida Sans Typewriter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserChng.Location = new System.Drawing.Point(74, 86);
            this.txtUserChng.Multiline = true;
            this.txtUserChng.Name = "txtUserChng";
            this.txtUserChng.Size = new System.Drawing.Size(374, 38);
            this.txtUserChng.TabIndex = 3;
            // 
            // txtPassChng
            // 
            this.txtPassChng.Font = new System.Drawing.Font("Lucida Sans Typewriter", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassChng.Location = new System.Drawing.Point(74, 193);
            this.txtPassChng.Multiline = true;
            this.txtPassChng.Name = "txtPassChng";
            this.txtPassChng.Size = new System.Drawing.Size(374, 38);
            this.txtPassChng.TabIndex = 4;
            // 
            // UpdateUserPass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(580, 332);
            this.Controls.Add(this.txtPassChng);
            this.Controls.Add(this.txtUserChng);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnUpdteSubmit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "UpdateUserPass";
            this.Text = "Enter User Name :";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdteSubmit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUserChng;
        private System.Windows.Forms.TextBox txtPassChng;
    }
}