﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class LogIn : Form
    {
        Dictionary<string, string> logInUsers = new Dictionary<string, string>();
        string CName, CPass;
     

        public LogIn()
        {
            InitializeComponent();
        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            txtUserName.Focus();
        }

        SqlConnection scon = null;

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            SignUpPage sp = new SignUpPage();
            sp.Show();
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            logInUsers.Clear();
            scon = new SqlConnection("Data Source=MOHIT-PC;Initial Catalog=StoreHouse;Integrated Security=True");
            
            scon.Open();

            SqlCommand scmd = new SqlCommand("Select * from LogInUsers", scon);
            SqlDataReader sdr = scmd.ExecuteReader();
           
             
            while (sdr.Read())
            {
                 CName = sdr.GetValue(1).ToString();
                 CPass = sdr.GetValue(2).ToString();
                logInUsers.Add(CName, CPass);
            }
            if (logInUsers.ContainsKey(txtUserName.Text) && logInUsers.ContainsValue(txtpass.Text))
            {
                MessageBox.Show("Welcome " + txtUserName.Text);
                this.Hide(); 
                DashBoard db = new DashBoard(txtUserName.Text);
                db.Show();
               
            }
            else
            {
                if (!(logInUsers.ContainsKey(txtUserName.Text)))

                {
                    MessageBox.Show("Your User Name is not registered....");
                    MessageBox.Show("Please Sin Up yourself...");
                }
                else if (logInUsers.ContainsKey(txtUserName.Text) && !(logInUsers.ContainsValue(txtpass.Text)))
                {
                    MessageBox.Show("You have entered an incorrect password.");
                }
                Console.WriteLine(txtpass.Text);
            }
        }
    }
}
