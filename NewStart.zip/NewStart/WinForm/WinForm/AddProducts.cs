﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class AddProducts : Form
    {
        public AddProducts()
        {
            InitializeComponent();
        }
        SqlConnection scon = null;
        private void btnAddproduct_Click(object sender, EventArgs e)
        {
            scon = new SqlConnection("Data Source=MOHIT-PC;Initial Catalog=StoreHouse;Integrated Security=True");

            scon.Open();
            SqlCommand scmd = new SqlCommand("insert into Products values (@PName ,@PAmt )", scon);

            scmd.Parameters.Add("@PName", SqlDbType.VarChar, 20).Value = txtPName.Text;
            scmd.Parameters.Add("@PAmt", SqlDbType.Int, 6).Value = txtPAmt.Text;


            int res = scmd.ExecuteNonQuery();
            MessageBox.Show(res + " is added in your inventory...");

            this.Hide();


        }
    }
}
