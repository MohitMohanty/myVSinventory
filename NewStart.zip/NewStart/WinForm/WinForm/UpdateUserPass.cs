﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class UpdateUserPass : Form
    {
        int CustID;
        string UserName;
        public UpdateUserPass()
        {
            InitializeComponent();
        }

        SqlConnection scon = null;
     
        public int cust(ref string UserName)
        {
            scon = new SqlConnection("Data Source=MOHIT-PC;Initial Catalog=StoreHouse;Integrated Security=True");
            scon.Open();
            
            SqlCommand scmd = new SqlCommand("Select @CustID = CustID,@CustName =CustName from LogInUsers where CustName = @CustName", scon);

            //scmd.Parameters.Add("@CustName", SqlDbType.VarChar, 20).Value = txtUserChng.Text;
            SqlParameter sp1 = new SqlParameter();
            sp1.ParameterName = "@CustName";
            sp1.SqlDbType = SqlDbType.VarChar;
            sp1.Direction = ParameterDirection.InputOutput;
            sp1.Value = txtUserChng.Text;

            SqlParameter sp2 = new SqlParameter();
            sp2.ParameterName = "@CustID";
            sp2.SqlDbType = SqlDbType.Int;
            sp2.Direction = ParameterDirection.Output;

            scmd.Parameters.Add(sp1);
            scmd.Parameters.Add(sp2);
            scmd.ExecuteNonQuery();
            CustID = (int)sp2.Value;
            UserName = sp1.Value.ToString();
            Console.WriteLine(CustID);

            return CustID;
        }
        private void btnUpdteSubmit_Click(object sender, EventArgs e)
        {
            scon = new SqlConnection("Data Source=MOHIT-PC;Initial Catalog=StoreHouse;Integrated Security=True");

            scon.Open();

            SqlCommand scmd = new SqlCommand("update LogInUsers set CustName = @CustName,Passwd = @Passwd where CustID = @CustID ", scon);

            scmd.Parameters.Add("@CustName", SqlDbType.VarChar, 20).Value = txtUserChng.Text;
            scmd.Parameters.Add("@Passwd", SqlDbType.VarChar, 20).Value = txtPassChng.Text;
           
            scmd.Parameters.Add("@CustID", SqlDbType.VarChar, 20).Value = cust(ref UserName);

                int res = scmd.ExecuteNonQuery();
                MessageBox.Show(res.ToString() + "ID PASSWORD is updated successfully." + UserName);
                this.Hide();
            }
        }
    }

