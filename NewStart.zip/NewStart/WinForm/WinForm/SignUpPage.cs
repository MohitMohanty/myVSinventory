﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class SignUpPage : Form
    {
        public SignUpPage()
        {
            InitializeComponent();
        }
        SqlConnection scon = null;
        private void BtnSignUpSubmit_Click(object sender, EventArgs e)
        {
            scon = new SqlConnection("Data Source=MOHIT-PC;Initial Catalog=StoreHouse;Integrated Security=True");

            scon.Open();

            SqlCommand scmd = new SqlCommand("Insert into LogInUsers values (@CustName , @Passwd ,@ConfmPasswd)", scon);

            scmd.Parameters.Add("@CustName", SqlDbType.VarChar, 20).Value = txtUserName.Text;
            scmd.Parameters.Add("@Passwd", SqlDbType.VarChar, 20).Value = txtpass.Text;
            scmd.Parameters.Add("@ConfmPasswd", SqlDbType.VarChar, 20).Value = txtCnfmPsswd.Text;
            int res = scmd.ExecuteNonQuery();
            MessageBox.Show(res.ToString() + "row is registered");

            LogIn lg = new LogIn();
            this.Hide();
            lg.Show();
        }
    }
}
